"use strict";

const http = require("node:http");
const { execFile } = require("node:child_process");
const { createHash, timingSafeEqual } = require("node:crypto");
const { readFileSync } = require("node:fs");
const { isIPv4 } = require("node:net");
const { networkInterfaces } = require("node:os");
const path = require("node:path");
const { promisify } = require("node:util");

const exec = promisify(execFile);
const usbHost = "192.168.77.1";
const usbOrigin = "http://" + usbHost;
const readPaths = new Set([
  "/", "/style.css", "/app.js", "/axora-logo.webp", "/axora-poses.webp",
  "/wireless", "/wireless.css", "/wireless.js", "/axora-air-logo.png", "/axora-home-logo.webp",
  "/api/wireless", "/api/rx/version"
]);
const actions = new Map([
  ["/api/command", {type:"application/axora-command", max:80, pattern:/^[A-Z0-9 +\-]+$/}],
  ["/api/wireless", {type:"application/axora-radio", max:19, pattern:/^(?:SELECT [0-9A-Fa-f]{12}|CONFIRM|CANCEL|CLEAR)$/}]
]);
const digest = value => createHash("sha256").update(value).digest();
const ipv4 = value => value.split(".").reduce((out,part) => (out << 8) | Number(part),0);
const axoraAddress = address => address.startsWith("192.168.77.");

function localPeer(remote, local) {
  return isIPv4(remote) && (ipv4(remote)&ipv4(local.netmask)) === (ipv4(local.address)&ipv4(local.netmask));
}

function reply(response, code, message, headers = {}) {
  response.writeHead(code, {"Content-Type":"text/plain; charset=utf-8","Cache-Control":"no-store",...headers});
  response.end(message);
}

function createServer({password, port, getNetwork, deviceHost = usbHost, devicePort = 80, idleTimeout = 6000}) {
  const passwordHash = digest("Basic " + Buffer.from("axora:" + password).toString("base64"));
  const server = http.createServer({headersTimeout:8000,requestTimeout:10000},async (request,response) => {
    const {lan,usb} = getNetwork();
    const local = lan.find(entry => entry.address === request.socket.localAddress);
    const suffix = port === 80 ? "" : ":" + port;
    const host = request.headers.host?.toLowerCase();
    if (!local || !localPeer(request.socket.remoteAddress,local) ||
        (host !== "axora.local"+suffix && host !== local.address+suffix)) {
      return reply(response,403,"Use AXORA from the local network.");
    }
    if (!timingSafeEqual(digest(request.headers.authorization || ""),passwordHash)) {
      return reply(response,401,"AXORA LAN login required.",{
        "WWW-Authenticate":'Basic realm="AXORA LAN", charset="UTF-8"'
      });
    }
    if (!usb) return reply(response,503,"Connect AXORA or Axora Air to this PC.");

    let body;
    const action = request.method === "POST" && actions.get(request.url);
    if (action) {
      if (request.headers.origin?.toLowerCase() !== "http://"+host || request.headers["content-type"] !== action.type)
        return reply(response,403,"Open the AXORA page at its LAN address.");
      const length = Number(request.headers["content-length"]);
      if (!Number.isInteger(length) || length < 1 || length > action.max)
        return reply(response,400,"Invalid AXORA request length.");
      try {
        const chunks = [];
        for await (const chunk of request) chunks.push(chunk);
        body = Buffer.concat(chunks);
      } catch {
        return reply(response,400,"Incomplete AXORA request.");
      }
      if (body.length !== length || !action.pattern.test(body.toString("latin1")))
        return reply(response,400,"Invalid AXORA request.");
    } else if (request.method !== "GET" || !readPaths.has(request.url)) {
      return reply(response,404,"AXORA route unavailable over LAN.");
    }

    const headers = {Host:usbHost};
    if (body) Object.assign(headers,{Origin:usbOrigin,"Content-Type":action.type,"Content-Length":body.length});
    const upstream = http.request({host:deviceHost,port:devicePort,path:request.url,method:request.method,headers,
      localAddress:usb,timeout:idleTimeout},result => {
      const forwarded = {"Cache-Control":"no-store","X-AXORA-LAN-Proxy":"1","X-AXORA-Air-Proxy":"1"};
      for (const key of ["content-type","content-encoding","content-length","content-security-policy","location"])
        if (result.headers[key]) forwarded[key]=result.headers[key];
      response.writeHead(result.statusCode,forwarded);
      result.on("error",()=>response.destroy());
      result.pipe(response);
    });
    upstream.on("timeout",()=>upstream.destroy());
    upstream.on("error",()=>{
      if (response.headersSent) response.destroy();
      else reply(response,502,"AXORA is unavailable over USB.");
    });
    response.on("close",()=>upstream.destroy());
    upstream.end(body);
  });
  return server;
}

async function configuredInterfaces(trustedNetwork) {
  const shell = path.join(process.env.SystemRoot,"System32","WindowsPowerShell","v1.0","powershell.exe");
  const script = "[Console]::OutputEncoding=[Text.Encoding]::UTF8; $ErrorActionPreference='Stop'; " +
    "$allowed=@(Get-NetConnectionProfile | Where-Object { $_.NetworkCategory -in 'Private','DomainAuthenticated' -or ($env:AXORA_LAN_NETWORK -and $_.InstanceID -eq $env:AXORA_LAN_NETWORK) } | Select-Object -ExpandProperty InterfaceAlias); " +
    "$usb=@(Get-NetAdapter | Where-Object { $_.InterfaceDescription -match '^AXORA.*USB Network' } | Select-Object -ExpandProperty Name); " +
    "@{private=$allowed;usb=$usb} | ConvertTo-Json -Compress";
  const {stdout} = await exec(shell,["-NoProfile","-NonInteractive","-Command",script],
    {windowsHide:true,timeout:5000,encoding:"utf8",env:{...process.env,AXORA_LAN_NETWORK:trustedNetwork}});
  const adapters=JSON.parse(stdout);
  return {private:new Set(adapters.private),usb:new Set(adapters.usb)};
}

function inspectInterfaces(allowed, interfaces = networkInterfaces()) {
  const lan = [];
  let usb;
  for (const [name,list] of Object.entries(interfaces)) {
    for (const entry of list) {
      if (entry.family !== "IPv4" || entry.internal) continue;
      if (axoraAddress(entry.address)) {
        if (allowed.usb.has(name) && entry.address !== usbHost) usb = entry.address;
        continue;
      }
      if (allowed.private.has(name) && !entry.address.startsWith("169.254."))
        lan.push({address:entry.address,netmask:entry.netmask});
    }
  }
  return {lan,usb};
}

function probeUsb(address) {
  if (!address) return Promise.resolve(false);
  return new Promise(resolve=>{
    const request=http.get({host:usbHost,localAddress:address,path:"/api/version",timeout:1200},response=>{
      let value="";
      response.setEncoding("utf8");
      response.on("data",chunk=>{
        value+=chunk;
        if(value.length>40) request.destroy();
      });
      response.on("end",()=>resolve(response.statusCode===200 && /^\d+\.\d+\.\d+$/.test(value.trim())));
      response.on("error",()=>resolve(false));
    });
    request.on("timeout",()=>request.destroy());
    request.on("error",()=>resolve(false));
  });
}

function start({password,port=80,trustedNetwork=""}) {
  if (typeof password!=="string" || password.length<10 || !Number.isInteger(port) || port<1 || port>65535 ||
      (trustedNetwork && !/^\{[a-f0-9-]+\}$/i.test(trustedNetwork)))
    throw new Error("Invalid AXORA LAN configuration");
  const {getResponder}=require("@homebridge/ciao");
  const mdns=getResponder();
  const emptyAdapters=()=>({private:new Set(),usb:new Set()});
  let network={lan:[],usb:undefined}, allowed=emptyAdapters(), profileAt=0, service, advertised="";
  let stopped=false, timer;
  async function refresh() {
    try {
      if (Date.now()>=profileAt) {
        allowed=await configuredInterfaces(trustedNetwork).catch(error=>{
          console.error("AXORA network:",error.message);
          return emptyAdapters();
        });
        profileAt=Date.now()+7000;
      }
      const next=inspectInterfaces(allowed);
      if (!(await probeUsb(next.usb))) next.usb=undefined;
      if (stopped) return;
      network=next;
      const addresses=next.usb?next.lan.map(entry=>entry.address).sort():[];
      const key=addresses.join(",");
      if (key!==advertised) {
        if (service) {
          await service.destroy();
          service=undefined;
          advertised="";
        }
        if (addresses.length && !stopped) {
          service=mdns.createService({name:"AXORA",hostname:"axora",type:"http",port,
            restrictedAddresses:addresses,disabledIpv6:true});
          await service.advertise();
          advertised=key;
        }
      }
    } catch (error) {
      console.error("AXORA LAN:",error.message);
    } finally {
      if (!stopped) timer=setTimeout(refresh,2000);
    }
  }
  const server=createServer({password,port,getNetwork:()=>network});
  server.on("error",error=>{console.error("AXORA LAN:",error.message);process.exit(1);});
  server.listen(port,"0.0.0.0",refresh);
  function shutdown(){
    stopped=true;
    clearTimeout(timer);
    server.close();
    mdns.shutdown().finally(()=>process.exit(0));
  }
  process.once("SIGINT",shutdown);
  process.once("SIGTERM",shutdown);
}

if (require.main===module) start(JSON.parse(readFileSync(process.argv[2],"utf8")));
module.exports={createServer,inspectInterfaces,localPeer};
