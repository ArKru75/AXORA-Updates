param([switch]$Disable,[switch]$Quiet,[ValidateRange(1,65535)][int]$Port=80)
$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (!$principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    if ($Quiet) { throw 'AXORA LAN installation needs administrator access.' }
    $mode = if ($Disable) { ' -Disable' } else { '' }
    $arguments = '-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"' + $mode + ' -Port ' + $Port
    try {
        $worker = Start-Process -FilePath "$PSHOME\powershell.exe" -ArgumentList $arguments -Verb RunAs -PassThru -Wait
        exit $worker.ExitCode
    } catch { Write-Host $_.Exception.Message; exit 1 }
}

$taskName = 'AXORA LAN'
$destination = Join-Path ([Environment]::GetFolderPath('ProgramFiles')) 'AXORA\LAN'
$settings = Join-Path $destination 'settings.json'
$node = Join-Path $destination 'runtime\node.exe'
$service = Join-Path $destination 'lan.cjs'
$existing = Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
$rules = @('AXORA-LAN-HTTP','AXORA-LAN-mDNS')

try {
    if ($Disable) {
        if ($existing) {
            if ($existing.State -eq 'Running') { Stop-ScheduledTask -TaskName $taskName }
            Unregister-ScheduledTask -TaskName $taskName -Confirm:$false
        }
        Get-NetFirewallRule -Name $rules -ErrorAction SilentlyContinue | Remove-NetFirewallRule
        Write-Host 'AXORA LAN disabled.'
        if (!$Quiet) { Read-Host 'Press Enter to close' }
        exit 0
    }

    $assets = @('lan.cjs','runtime','node_modules')
    foreach ($item in @('lan.cjs','runtime\node.exe','node_modules\@homebridge\ciao\package.json')) {
        if (!(Test-Path -LiteralPath (Join-Path $PSScriptRoot $item) -PathType Leaf)) {
            throw 'Extract the complete AXORA LAN zip before running Install.cmd.'
        }
    }
    $legacyDir = Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'AXORA\LanProxy'
    $legacyConfig = Join-Path $legacyDir 'settings.json'
    $legacyLauncher = Join-Path ([Environment]::GetFolderPath('Startup')) 'AXORA LAN Proxy.vbs'
    $legacyServers = @()
    $listeners = @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)
    foreach ($listenerId in ($listeners.OwningProcess | Select-Object -Unique)) {
        $process = Get-CimInstance Win32_Process -Filter "ProcessId=$listenerId"
        $command = [string]$process.CommandLine
        if ($existing -and $process.ExecutablePath -eq $node -and $command.Contains($service)) { continue }
        if ($process.Name -eq 'node.exe' -and $command.Contains('axora-lan-proxy.cjs') -and $command.Contains($legacyConfig)) {
            $legacyServers += $process
            continue
        }
        throw "Port $Port is already used by another program. Close it before installing AXORA LAN."
    }
    if ($existing.State -eq 'Running') { Stop-ScheduledTask -TaskName $taskName }
    foreach ($process in $legacyServers) {
        Stop-Process -Id $process.ProcessId
        Wait-Process -Id $process.ProcessId -Timeout 5 -ErrorAction SilentlyContinue
    }

    $null = New-Item -ItemType Directory -Path $destination -Force
    foreach ($item in $assets) {
        Copy-Item -LiteralPath (Join-Path $PSScriptRoot $item) -Destination $destination -Recurse -Force
    }
    $password = ''
    foreach ($candidate in @($settings,$legacyConfig)) {
        if (Test-Path -LiteralPath $candidate) {
            $saved = Get-Content -LiteralPath $candidate -Raw | ConvertFrom-Json
            if ($saved.password -is [string] -and $saved.password.Length -ge 10) {
                $password = $saved.password
                break
            }
        }
    }
    if (!$password) {
        $bytes = New-Object byte[] 15
        $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
        try { $rng.GetBytes($bytes) } finally { $rng.Dispose() }
        $password = [Convert]::ToBase64String($bytes).Replace('+','-').Replace('/','_')
    }
    $utf8 = [Text.UTF8Encoding]::new($false)
    $physical = @(Get-NetAdapter -Physical | Where-Object Status -eq 'Up' | Select-Object -ExpandProperty ifIndex)
    $route = Get-NetRoute -AddressFamily IPv4 -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue |
        Where-Object { $_.InterfaceIndex -in $physical } | Sort-Object { $_.RouteMetric + $_.InterfaceMetric } | Select-Object -First 1
    $network = if ($route) { Get-NetConnectionProfile -InterfaceIndex $route.InterfaceIndex -ErrorAction SilentlyContinue | Select-Object -First 1 }
    [IO.File]::WriteAllText($settings,(@{port=$Port;password=$password;trustedNetwork=[string]$network.InstanceID} | ConvertTo-Json -Compress),$utf8)
    $acl = Get-Acl -LiteralPath $settings
    $acl.SetAccessRuleProtection($true,$false)
    foreach ($sid in @('S-1-5-32-544','S-1-5-18','S-1-5-19')) {
        $account = [Security.Principal.SecurityIdentifier]::new($sid)
        $rights = if ($sid -eq 'S-1-5-19') { 'Read' } else { 'FullControl' }
        $acl.SetAccessRule([Security.AccessControl.FileSystemAccessRule]::new($account,$rights,'Allow'))
    }
    Set-Acl -LiteralPath $settings -AclObject $acl

    Get-NetFirewallRule -Name $rules -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    # The proxy also checks the active network profile and client IPv4 subnet.
    $ruleOptions = @{Direction='Inbound';Action='Allow';Profile='Any';RemoteAddress='LocalSubnet';Program=$node}
    New-NetFirewallRule @ruleOptions -Name $rules[0] -DisplayName 'AXORA LAN web access' -Protocol TCP -LocalPort $Port | Out-Null
    New-NetFirewallRule @ruleOptions -Name $rules[1] -DisplayName 'AXORA LAN discovery' -Protocol UDP -LocalPort 5353 | Out-Null

    $action = New-ScheduledTaskAction -Execute $node -WorkingDirectory $destination -Argument ('"{0}" "{1}"' -f $service,$settings)
    $trigger = New-ScheduledTaskTrigger -AtStartup
    $localService = [Security.Principal.SecurityIdentifier]::new('S-1-5-19')
    $account = $localService.Translate([Security.Principal.NTAccount]).Value
    $runAs = New-ScheduledTaskPrincipal -UserId $account -LogonType ServiceAccount
    $retry = New-TimeSpan -Minutes 1
    $taskSettings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 6 -RestartInterval $retry -MultipleInstances IgnoreNew
    Register-ScheduledTask -TaskName $taskName -Action $action -Trigger $trigger -Principal $runAs -Settings $taskSettings -Force | Out-Null
    Start-ScheduledTask -TaskName $taskName
    $ready = $false
    for ($i = 0; $i -lt 20; $i++) {
        Start-Sleep -Milliseconds 500
        foreach ($listener in @(Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue)) {
            $worker = Get-CimInstance Win32_Process -Filter "ProcessId=$($listener.OwningProcess)" -ErrorAction SilentlyContinue
            if ($worker.ExecutablePath -eq $node) { $ready = $true; break }
        }
        if ($ready) { break }
    }
    if (!$ready) { throw 'AXORA LAN could not start listening. Check the AXORA LAN task in Windows Task Scheduler.' }
    if ($legacyServers.Count -and (Test-Path -LiteralPath $legacyLauncher)) {
        $prior = Get-Content -LiteralPath $legacyLauncher -Raw
        if ($prior.Contains('axora-lan-proxy.cjs') -and $prior.Contains($legacyConfig)) {
            Rename-Item -LiteralPath $legacyLauncher -NewName 'AXORA LAN Proxy.vbs.disabled' -Force
        }
    }

    $access = Join-Path ([Environment]::GetFolderPath('Desktop')) 'AXORA LAN.txt'
    $url = if ($Port -eq 80) { 'http://axora.local/' } else { "http://axora.local:${Port}/" }
    $details = [string]::Join([Environment]::NewLine,@($url,'Username: axora',"Password: $password",''))
    [IO.File]::WriteAllText($access,$details,$utf8)
    Write-Host 'AXORA LAN is installed. Login details are in AXORA LAN.txt on your desktop.'
    $trusted = @(Get-NetConnectionProfile | Where-Object { $_.NetworkCategory -in 'Private','DomainAuthenticated' })
    if ($network) { Write-Host "AXORA LAN uses your current network: $($network.Name)." }
    elseif (!$trusted.Count) { Write-Host 'Use a Private network or run Install.cmd while connected to your home network.' }
    if (!$Quiet) { Read-Host 'Press Enter to close' }
} catch {
    Write-Host $_.Exception.Message
    if (!$Quiet) { Read-Host 'Press Enter to close' }
    exit 1
}
