AXORA CALIBRATOR 1.1.19

Розпакуйте архів повністю та запустіть AxoraCalibrator.exe.
На головному вікні виберіть AXORA (3 кнопки) або AXORA Pro (9 кнопок). Вибір моделі зберігається.
З прошивкою 2.1.20 кольори тесту «Веселка» плавно рухаються від першого світлодіода до останнього.
У режимі «Експерт» відкрийте «Оновлення» → «Перевірити оновлення».
Для нової або вже прошитої Pro Micro 5 В / 16 МГц із Caterina:
«Встановлення / перепрошивання» → «Оновити USB-порти» → виберіть порт,
підтвердьте плату → «Прошити плату автоматично». Ручний RESET не потрібен.
Сервісний режим потребує мастер-пароля; розблокування діє на один запис.
Потрібен робочий USB COM із перезапуском на 1200 бод; інакше потрібен ISP.
Оновлення доступні без токена, пароля й входу в GitHub.
Кнопка CAD у верхній частині вікна вмикає та вимикає керування моделлю.
Підсвічування: яскравість і бігуча «Веселка» з прошивкою 2.1.20.
При звичайному оновленні AXORA калібрування копіюється перед записом.
Для запису потрібен установлений AVRDUDE з Arduino AVR Boards.
AxoraHidRecorder.exe — додаткова утиліта пасивного запису HID.

Extract the whole ZIP and run AxoraCalibrator.exe.
Choose AXORA (3 buttons) or AXORA Pro (9 buttons) on the main window. The model selection is saved.
With firmware 2.1.20, the Rainbow test colors flow smoothly from the first LED to the last.
Select Expert → Updates → Check for updates. No token or sign-in required.
For a new or previously flashed Pro Micro 5 V / 16 MHz with Caterina:
Install / reflash board → Refresh USB ports → select and confirm the board →
Flash board automatically. No manual RESET needed. Requires working USB COM
and 1200-baud restart; otherwise, an ISP programmer is required.
This service mode requires a master password; each unlock permits one flash.
Use the CAD button at the top of the window to turn model control on or off.
Windows with .NET Framework 4.8; an installed Arduino AVR Boards AVRDUDE
is required for firmware programming. Normal AXORA updates back up calibration.

https://github.com/ArKru75/AXORA-Updates
