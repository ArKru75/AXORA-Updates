AXORA CALIBRATOR 1.1.6

Розпакуйте архів повністю та запустіть AxoraCalibrator.exe.
У розділі «Прошивка»: «Перевірити GitHub» → «Оновити прошивку».
Оновлення доступні без токена, пароля й входу в GitHub.
Кнопка CAD у верхній частині вікна вмикає та вимикає керування моделлю.
RGB: яскравість 0–100%, збереження та R/G/B/W-тести; потрібна прошивка 2.1.13.
Калібрування та налаштування перевіряються й копіюються перед прошиванням.
Для запису потрібен установлений AVRDUDE з Arduino AVR Boards.
AxoraHidRecorder.exe — додаткова утиліта пасивного запису HID.

Extract the whole ZIP and run AxoraCalibrator.exe.
Firmware → Check GitHub → Update firmware. No token or sign-in required.
Use the CAD button at the top of the window to turn model control on or off.
Windows with .NET Framework 4.8; an installed Arduino AVR Boards AVRDUDE
is required for firmware programming. Calibration is backed up before writing.

https://github.com/ArKru75/AXORA-Updates
