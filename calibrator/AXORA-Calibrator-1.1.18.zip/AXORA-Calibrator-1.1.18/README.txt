AXORA CALIBRATOR 1.1.18

Розпакуйте ZIP і запустіть AxoraCalibrator.exe.
Виберіть модель, підключіть AXORA через USB та натисніть «Підключити».
Поруч із моделлю виберіть режим «Звичайний» або «Експерт». У звичайному доступні Калібрування, Налаштування та Підсвічування. У режимі «Експерт» доступні всі розділи, зокрема Центри датчиків і Журнал. Вибір зберігається між запусками.
Для перевірки кнопок і зміни їхніх призначень виберіть «Експерт» → «Кнопки».
У «Підсвічуванні» змінюйте яскравість або натисніть «Тест “Веселка”».
Для веселки й профілю 3/7 світлодіодів потрібна прошивка 2.1.19.
Для прошивки виберіть «Експерт» → «Оновлення» → «Перевірити оновлення».

Extract the ZIP and run AxoraCalibrator.exe.
Select the model, connect AXORA via USB, and click Connect.
Select Normal or Expert next to the model. Normal shows Calibration, Settings and Lighting. Expert shows all sections, including Sensor centers and Log. Your selection is saved between launches.
To test or reassign buttons, select Expert → Buttons.
Lighting offers brightness and a Rainbow test. Firmware 2.1.19 enables the
rainbow and the 3/7 LED profiles.
For firmware, select Expert → Updates → Check for updates.

Windows / .NET Framework 4.8
https://github.com/ArKru75/AXORA-Updates
