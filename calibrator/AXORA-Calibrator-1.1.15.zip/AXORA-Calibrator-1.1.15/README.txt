AXORA CALIBRATOR 1.1.15

Розпакуйте ZIP і запустіть AxoraCalibrator.exe у Windows.
Виберіть AXORA або AXORA Pro, підключіть пристрій через USB і натисніть «Підключити».
«Калібрування» містить налаштування центру й повне калібрування.
У «Кнопках» перевірте натискання або змініть призначення та натисніть «Зберегти призначення».
Щоб керувати моделлю, ввімкніть CAD у верхній панелі.
Для прошивки відкрийте «Оновлення» → «Перевірити оновлення» → «Оновити прошивку».
Ручні центри та журнал відкриваються через «Додатково». Кнопка «Резервні копії»
у калібруванні відкриває дії з копіями в журналі.

Extract the ZIP and run AxoraCalibrator.exe on Windows.
Select AXORA or AXORA Pro, connect the device via USB, and click Connect.
Use Calibration to set the center or run a full calibration.
Use Buttons to test or change assignments, then click Save assignments.
Enable CAD in the top bar to control your model.
For firmware, choose Updates → Check for updates → Update firmware.
Open Advanced for sensor centers and the log. Backups in Calibration
opens backup and restore actions in the log.

Windows / .NET Framework 4.8
https://github.com/ArKru75/AXORA-Updates
