AXORA CALIBRATOR 1.1.10

Розпакуйте архів повністю та запустіть AxoraCalibrator.exe.
У розділі «Прошивка»: «Перевірити GitHub» → «Оновити прошивку».
Для нової або вже прошитої Pro Micro 5 В / 16 МГц із Caterina:
«Встановлення / перепрошивання» → «Оновити USB-порти» → виберіть порт,
підтвердьте плату → «Прошити плату автоматично». Ручний RESET не потрібен.
Сервісний режим потребує мастер-пароля; розблокування діє на один запис.
Потрібен робочий USB COM із перезапуском на 1200 бод; інакше потрібен ISP.
Оновлення доступні без токена, пароля й входу в GitHub.
Кнопка CAD у верхній частині вікна вмикає та вимикає керування моделлю.
RGB: яскравість 0–100%, збереження та R/G/B/W-тести.
Кількість LED: 1-16, типово 3; «Зберегти кількість» (прошивка 2.1.15).
При звичайному оновленні AXORA калібрування копіюється перед записом.
Для запису потрібен установлений AVRDUDE з Arduino AVR Boards.
AxoraHidRecorder.exe — додаткова утиліта пасивного запису HID.

Extract the whole ZIP and run AxoraCalibrator.exe.
Firmware → Check GitHub → Update firmware. No token or sign-in required.
For a new or previously flashed Pro Micro 5 V / 16 MHz with Caterina:
Install / reflash board → Refresh USB ports → select and confirm the board →
Flash board automatically. No manual RESET needed. Requires working USB COM
and 1200-baud restart; otherwise, an ISP programmer is required.
This service mode requires a master password; each unlock permits one flash.
Use the CAD button at the top of the window to turn model control on or off.
Windows with .NET Framework 4.8; an installed Arduino AVR Boards AVRDUDE
is required for firmware programming. Normal AXORA updates back up calibration.

https://github.com/ArKru75/AXORA-Updates
